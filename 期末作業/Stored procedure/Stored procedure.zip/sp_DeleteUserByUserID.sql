CREATE DEFINER=`catcat`@`192.168.56.1` PROCEDURE `sp_DeleteUserByUserID`(
	in in_user_id INT,
    out out_affected_row INT
)
BEGIN
-- 透過 sp_ DeleteUserByUserID，輸入會員 ID，進行刪除此會員。
-- output parameter: Number of affected row(int)

	-- DECLARE id_delete INT; -- 本來想做檢驗...
	-- SET id_delete = (SELECT isDeleted FROM tblUser WHERE idtblUser = in_user_id);
    
	UPDATE tblUser
    SET isDeleted = 1
    WHERE (idtblUser = in_user_id) AND (isDeleted = 0);
    
    SET out_affected_row = row_count();
    
END