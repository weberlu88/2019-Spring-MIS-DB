CREATE PROCEDURE `sp_UserLogin` (
	IN in_Email VARCHAR(200),
    OUT out_HashedPwd VARCHAR(512)
    )
BEGIN
-- 透過 sp_UserLogin，輸入會員的電子信箱，可以獲得其使用者的電子信箱,姓氏,名字,生日,salt,UUID 以及註冊日期，進行會員登入。
    
    SELECT HashedPwd
    INTO out_HashedPwd -- 輸出單一欄位out_HashedPwd
    FROM tblUserCredential
    JOIN tblUser ON (tblUser.idtblUser = tblUserCredential.UserID) -- id相同就join
    WHERE (Email = in_Email) AND (tblUser.isDeleted != 1); -- 比對in_email
    
    SELECT Email, FullName, Dob, Salt, UUID, RegisterDateTime
    FROM tblUser
    JOIN tblUserCredential ON (tblUser.idtblUser = tblUserCredential.UserID) -- id相同就join
    WHERE (Email = in_Email) AND (tblUser.isDeleted != 1);
    
END
